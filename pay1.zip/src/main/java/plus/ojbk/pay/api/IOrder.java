package plus.ojbk.pay.api;


import plus.ojbk.pay.model.Order;

public interface IOrder {
    Order getOrderById(String id);
}
