package plus.ojbk.pay.api;

import plus.ojbk.pay.model.Product;

import java.util.List;

public interface IProduct {

    Product getProductById(String id);

    List<Product> getProducts();

}
