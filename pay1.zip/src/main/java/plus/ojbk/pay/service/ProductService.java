package plus.ojbk.pay.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import plus.ojbk.pay.api.IProduct;
import plus.ojbk.pay.model.Product;

import java.util.List;

@Service
public class ProductService implements IProduct {
    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public Product getProductById(String id) {
        Query query = new Query(Criteria.where("_id").is(id));
        return mongoTemplate.findOne(query, Product.class);
    }

    @Override
    public List<Product> getProducts() {
        Query query = new Query();
        return mongoTemplate.find(query,Product.class);
    }
}
