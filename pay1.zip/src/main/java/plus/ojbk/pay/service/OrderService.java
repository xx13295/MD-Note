package plus.ojbk.pay.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import plus.ojbk.pay.api.IOrder;
import plus.ojbk.pay.model.Order;

@Service
public class OrderService implements IOrder {

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public Order getOrderById(String id) {
        Query query = new Query(Criteria.where("_id").is(id));
        return mongoTemplate.findOne(query,Order.class);
    }
}
