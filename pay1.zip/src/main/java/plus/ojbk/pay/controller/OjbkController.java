package plus.ojbk.pay.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import plus.ojbk.pay.model.Order;
import plus.ojbk.pay.model.Product;
import plus.ojbk.pay.service.ProductService;
import plus.ojbk.pay.util.GeneralUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
public class OjbkController {
    @Autowired
    private ProductService productService;
    @Autowired
    private MongoTemplate mongoTemplate;
    /**
     * 获取产品列表
     * @return
     */
    @RequestMapping("getproduct.php")
    public Object getProductList(){
      List<Product> productList = productService.getProducts();

      return null;
    }

    /**
     * 保存订单
     * @param order
     * @param request
     * @return
     */
    @RequestMapping("saveorder.php")
    public Object saveOrder(Order order, HttpServletRequest request){
        String productId = order.getProductId();
        Product product = productService.getProductById(productId);
        String price = product.getPrice(); //单价
        int count = order.getBuyCount(); //购买数量

        //减库存
        String totalAmount = String.valueOf(Double.valueOf(price) * count); //算出总价格
        order.setTotalAmount(totalAmount);
        order.setSpbillCreateIp(GeneralUtils.getClientIP(request));
        order.setStatus(2);//设置待支付状态
        mongoTemplate.insert(order);

        return order;

    }


}
