package plus.ojbk.pay.api;

public interface IAliPay {
    /**
     * @link https://docs.open.alipay.com/api_1/alipay.trade.page.pay/
     * @param orderId
     * @return
     */
    String doAliPay(String orderId);


}
