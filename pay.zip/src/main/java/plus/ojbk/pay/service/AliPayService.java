package plus.ojbk.pay.service;

import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import plus.ojbk.pay.model.Order;
import com.alipay.api.request.AlipayTradePagePayRequest;
import org.springframework.stereotype.Component;
import plus.ojbk.pay.api.IAliPay;

import javax.annotation.Resource;
import java.util.Map;

@Component("aliPayService")
public class AliPayService implements IAliPay {
    private static final String pid = "2088102177878878";
    @Value("${ali.pay.sellerId}")
    private String sellerId;
    @Resource(name = "alipayRequest")
    private AlipayTradePagePayRequest alipayTradePagePayRequest;
    @Resource(name = "alipayClient")
    private AlipayClient alipayClient;
    @Autowired
    private OrderService orderService;
    private static final Logger logger = LoggerFactory.getLogger(AliPayService.class);
    /**
     * @link https://docs.open.alipay.com/api_1/alipay.trade.page.pay/
     * @param orderId
     * @return
     */
    @Override
    public String doAliPay(String orderId) {
        logger.info("开始支付");
        Order order = orderService.getOrderById(orderId);
        JSONObject bizContent = new JSONObject();
        bizContent.put("out_trade_no", order.getOutTradeNo());
        bizContent.put("total_amount", order.getTotalAmount());  //订单金额:   元.角分
        bizContent.put("subject",order.getSubject());            //订单标题
        bizContent.put("seller_id", sellerId);                   //收钱的卖家UID
        bizContent.put("product_code", "FAST_INSTANT_TRADE_PAY");//固定值
        bizContent.put("body", order.getBody());                 //订单描述
        bizContent.put("qr_pay_mode", "2");                      //跳转模式
        alipayTradePagePayRequest.setBizContent(bizContent.toString());
        String result = "fail";
        try {
            result = alipayClient.pageExecute(alipayTradePagePayRequest).getBody();
        } catch (AlipayApiException e) {
            // 出错了
            e.printStackTrace();
        }

        return result;
    }



}
