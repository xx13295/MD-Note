package plus.ojbk.pay.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
public class IndexController {

    private static final Logger logger = LoggerFactory.getLogger(IndexController.class);

    private ModelAndView forwardView = null;
    @GetMapping("/index.php")
    public ModelAndView index(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView modelAndView = new ModelAndView("/index/index");
        return modelAndView;
    }

    /**
     * 默认转发页面
     * @param request
     * @return
     */
    @GetMapping("/")
    public ModelAndView defaultPage(HttpServletRequest request) {
        if(forwardView == null) {
            forwardView = new ModelAndView("forward:" + request.getContextPath() + "/index.php");
        }
        logger.info("ojbk");
        return forwardView;
    }
}
