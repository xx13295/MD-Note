package plus.ojbk.pay.controller;

import com.alipay.api.internal.util.AlipaySignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import plus.ojbk.pay.config.AlipayConfig;
import plus.ojbk.pay.service.AliPayService;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @author 王小明
 * @Description 支付流程三步走
 * @one 创建订单 ---> 返回前台订单信息
 * @two 支付订单 ---> 返回前台支付结果
 * @three 完事
 *
 */
@RestController
public class AliPayController {

    @Autowired
    private AliPayService aliPayService;
    private static final Logger logger = LoggerFactory.getLogger(AliPayController.class);


    /**
     * @link https://docs.open.alipay.com/api_1/alipay.trade.page.pay/
     * @param orderId
     * @Description 开始支付操作
     * @return
     */
    @RequestMapping("doalipay.php")
    public Object doAliPay(String orderId) {

        String result = aliPayService.doAliPay(orderId);

        return result;
    }

   

}
